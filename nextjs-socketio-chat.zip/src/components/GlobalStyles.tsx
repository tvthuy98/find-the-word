import React from "react";
import { GlobalStyles } from "twin.macro";

export default function GlobalStylesComponent() {
  return <GlobalStyles />;
}
